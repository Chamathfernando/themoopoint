
import React from 'react';
import { NavLink, ServiceItem } from './types';

export const NAV_LINKS: NavLink[] = [
  { label: 'Our Promise', href: '#promise' },
  { label: 'Overview', href: '#overview' },
  { label: 'Our Story', href: '#story' },
  { label: 'What We Do', href: '#services' },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'evaluation',
    title: 'Evaluation & Selection',
    description: 'Comprehensive ERP evaluation, selection, and implementation tailored to your scale and objectives.',
    icon: (
      <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    id: 'modernisation',
    title: 'Customisation & Modernisation',
    description: 'Expert ERP customisation and modernisation to align legacy systems with current operational realities.',
    icon: (
      <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
      </svg>
    ),
  },
  {
    id: 'government',
    title: 'Public-Sector Systems',
    description: 'Specialized government ERP frameworks and enterprise systems designed for public-sector complexities.',
    icon: (
      <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
      </svg>
    ),
  },
  {
    id: 'reengineering',
    title: 'Business Re-engineering',
    description: 'Deep business process analysis and re-engineering to ensure enterprise systems actually work.',
    icon: (
      <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
      </svg>
    ),
  },
  {
    id: 'integration',
    title: 'Systems Integration',
    description: 'Seamless systems integration and data consolidation to provide a single source of truth.',
    icon: (
      <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
      </svg>
    ),
  },
  {
    id: 'optimisation',
    title: 'Stabilisation & Optimisation',
    description: 'ERP stabilisation and post-implementation optimisation to ensure long-term ROI and operational clarity.',
    icon: (
      <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
      </svg>
    ),
  },
];
